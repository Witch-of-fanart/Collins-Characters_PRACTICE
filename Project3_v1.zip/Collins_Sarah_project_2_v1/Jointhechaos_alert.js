function myfunction() {
    alert("HA! This is a fake website!");
}// JavaScript Document